#include <iostream>
using namespace std;

void mostrarMensaje(string msj){
  cout<<msj<<endl;
}

void mostrarMensajeStock(string prod, int stock, int precio){
  cout<<"El "<<prod<< " al principio del dia tenia "<<stock<< "stock y su precio es de $"<<precio<<endl;
}

int pedirInt(string msj){
  int num;
  cout<<msj<<endl;
  cin>>num;
  return num;
}


string pedirString(string msj){
  string palabra;
  cout<<msj<<endl;
  cin>>palabra;
  return palabra;
}

int pedirProducto(string msj, int stock){
  int num;
  num=pedirInt(msj);
  while(num>stock){
    num=pedirInt("Ingrese de nuevo la cantidad del producto ya que la que indico antes sobrepaso el stock al principio del dia");
  }
  return num;
}

void masGasto(string ape, int cant){
  cout<<ape<<"fue la persona que mas gasto con un importe de $"<<cant<<endl;
}

void discriminadas(int efe, int tar){
  float num;
  num=efe/tar;
  cout<<"La cantidad de ventas discriminadas es de: "<<num<<endl;
}

void stockFinal(int a, int b, int c, int d, int e, int f, int g, int h){
  cout<<"El stock al final del dia del producto Barkito fue de: "<<a<<endl;
  cout<<"El stock al final del dia del producto HarinaDaPan fue de: "<<b<<endl;
  cout<<"El stock al final del dia del producto QuitaManchas fue de: "<<g<<endl;
  cout<<"El stock al final del dia del producto FirmeSandwich fue de: "<<h<<endl;
  cout<<"El stock al final del dia del producto AceiteNosepega fue de: "<<e<<endl;
  cout<<"El stock al final del dia del producto MateKozi2 fue de: "<<d<<endl;
  cout<<"El stock al final del dia del producto Percha fue de: "<<f<<endl;
  cout<<"El stock al final del dia del producto StanCafe fue de: "<<c<<endl;
}

void recaudacion(int recau){
 cout<<"La recaudacion total al final del dia fue de $"<<recau<<endl;
}

int main() {
  
  //variables
  
  int dni;
  string formaPago;
  string apellido;
  int stockBarkito=10;
  int stockHarina=10;
  int stockQuitaManchas=10;
  int stockFirmeSandwich=10;
  int stockAceite=10;
  int stockMate=10;
  int stockPercha=50;
  int stockCafe=10;
  int masPlataGasto=0;
  string masPlataAPe;
  int recaudacionTotal=0;
  float ventasDiscriminadas;
  int cantBarkito;
  int cantHarina;
  int cantMate;
  int cantPercha;
  int cantCafe;
  int cantFirmeSandwich;
  int cantAceite;
  int cantQuitaManchas;
  int precioVenta;
  int comprasTar=0;
  int comprasEfe=0;

  //constantes

  const int precioBarkito=5;
  const int precioHarina=10;
  const int precioQuitaManchas=7;
  const int precioFirmeSandwich=15;
  const int precioAceite=30;
  const int precioMate=8;
  const int precioPercha=2;
  const int precioCafe=3;


  mostrarMensaje("---------------------------------------------------------------");
  mostrarMensajeStock("Barkito", stockBarkito, precioBarkito);
  mostrarMensajeStock("HarinaDaPan", stockHarina, precioHarina);
  mostrarMensajeStock("QuitaManchas", stockQuitaManchas, precioQuitaManchas);
  mostrarMensajeStock("FirmeSandwich", stockFirmeSandwich, precioFirmeSandwich);
  mostrarMensajeStock("AceiteNosepega", stockAceite, precioAceite);
  mostrarMensajeStock("Percha", stockPercha, precioPercha);
  mostrarMensajeStock("MateKozi2", stockMate, precioMate);
  mostrarMensajeStock("StanCafe", stockCafe, precioCafe);
  mostrarMensaje("---------------------------------------------------------------");
  cin.get();
  dni=pedirInt("Ingrese el dni del cliente:");
  while(dni!=0){
    formaPago=pedirString("Ingrese la forma de pago");
    while(formaPago!="efectivo" && formaPago!="Efectivo"&&formaPago!="Tarjeta"&&formaPago!="tarjeta"){
      formaPago=pedirString("Ingrese de nuevo la forma de pago (efectivo o tarjeta)");
    }
    apellido=pedirString("Ingrese el apellido del cliente:");
    for(int i=0; i<1; i++){
      precioVenta=0;
      cantBarkito=pedirProducto("Ingrese la cantidad que se llevo el cliente del producto Barkito:",stockBarkito);
      stockBarkito=stockBarkito-cantBarkito;
      precioVenta=precioVenta+(cantBarkito*precioBarkito);

      cantHarina=pedirProducto("Ingrese la cantidad que se llevo el cliente del producto HarinaDaPan:",stockHarina);
      stockHarina=stockHarina-cantHarina;
      precioVenta=precioVenta+(cantHarina*precioHarina);

      cantQuitaManchas=pedirProducto("Ingrese la cantidad que se llevo el cliente del producto QuitaManchas:",stockQuitaManchas);
      stockQuitaManchas=stockQuitaManchas-cantQuitaManchas;
      precioVenta=precioVenta+(cantQuitaManchas*precioQuitaManchas);

      cantFirmeSandwich=pedirProducto("Ingrese la cantidad que se llevo el cliente del producto FirmeSandwich:",stockFirmeSandwich);
      stockFirmeSandwich=stockFirmeSandwich-cantFirmeSandwich;
      precioVenta=precioVenta+(cantFirmeSandwich*precioFirmeSandwich);
      
      cantAceite=pedirProducto("Ingrese la cantidad que se llevo el cliente del producto AceiteNosepega:",stockAceite);
      stockAceite=stockAceite-cantAceite;
      precioVenta=precioVenta+(cantAceite*precioAceite);
      
      cantMate=pedirProducto("Ingrese la cantidad que se llevo el cliente del producto MateKozi2:",stockMate);
      stockMate=stockMate-cantMate;
      precioVenta=precioVenta+(cantMate*precioMate);
      
      cantPercha=pedirProducto("Ingrese la cantidad que se llevo el cliente del producto Percha:",stockPercha);
      stockPercha=stockPercha-cantPercha;
      precioVenta=precioVenta+(cantPercha*precioPercha);
      
      cantCafe=pedirProducto("Ingrese la cantidad que se llevo el cliente del producto StanCafe:",stockCafe);
      stockCafe=stockCafe-cantCafe;
      precioVenta=precioVenta+(cantCafe*precioCafe);

      if(formaPago=="Efectivo"||formaPago=="efectivo"){
        precioVenta=precioVenta*0.9;
        recaudacionTotal=recaudacionTotal+precioVenta;
        comprasEfe=comprasEfe+1;
      }
      else{
        recaudacionTotal=recaudacionTotal+precioVenta;
        comprasTar=comprasTar+1;
      }

      if(precioVenta>masPlataGasto){
        masPlataAPe=apellido;
        masPlataGasto=precioVenta;
      } 
    }
    dni=pedirInt("Ingrese el dni de otro cliente:");
  }
 masGasto(masPlataAPe, masPlataGasto);
 discriminadas(comprasEfe, comprasTar);
 stockFinal(stockBarkito, stockHarina, stockCafe, stockMate,stockAceite, stockPercha, stockQuitaManchas, stockFirmeSandwich);
 recaudacion(recaudacionTotal);
 system("pause");
}