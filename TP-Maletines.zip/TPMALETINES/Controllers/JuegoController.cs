using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using TPMALETINES.Models;

namespace TPMALETINES.Controllers
{
    public class JuegoController : Controller
    {
        public IActionResult Tutorial()
        {
            return View();
        }

        public IActionResult Index()
        {
            ViewBag.Maletin=DealorNo.DevolverListaMaletines();
            ViewBag.Importes=DealorNo.DevolverListaImportes();
            return View();
        }

        public IActionResult elegirPrimerMaletin(int Maletin)
        {
            DealorNo.IniciarJuego(Maletin); 
            ViewBag.Maletin=DealorNo.DevolverListaMaletines();
            ViewBag.Importes=DealorNo.DevolverListaImportes();
            ViewBag.Jugadas=DealorNo.JugadasRestantes();
            ViewBag.MaletinElegido=DealorNo.DevolverMaletinElegido();
            ViewBag.Importe=-1;
            ViewBag.ImportesDescartados = DealorNo.ImportesDescartados;
            return View("Juego");
        }

        public IActionResult eleccionMaletin (int maletin)
        {
            int importe = DealorNo.abrirMaletin(maletin);
                ViewBag.Jugadas=DealorNo.JugadasRestantes();
                ViewBag.Maletin=DealorNo.DevolverListaMaletines();
                ViewBag.Importes=DealorNo.DevolverListaImportes();
                ViewBag.MaletinElegido=DealorNo.DevolverMaletinElegido();
                ViewBag.ImportesDescartados = DealorNo.ImportesDescartados;
            if(importe==-1){
               return View ("Error");
            }
            else{
                ViewBag.Importe=importe;
                if(DealorNo.JugadasRestantes()>0){
                    return View("Juego");
                }
                else{
                    ViewBag.Oferta=String.Format("{0:0}",DealorNo.OfertaBanca());
                    return View("Decision");
                }
            }
        }
        
         public IActionResult Decision(string decision)
        {   
            int aceptar=DealorNo.DecisionOferta(decision); 
            if(aceptar==-1){
                ViewBag.Jugadas=DealorNo.JugadasRestantes();
                ViewBag.Maletin=DealorNo.DevolverListaMaletines();
                ViewBag.Importes=DealorNo.DevolverListaImportes();
                ViewBag.MaletinElegido=DealorNo.DevolverMaletinElegido();
                ViewBag.ImportesDescartados = DealorNo.ImportesDescartados;
                ViewBag.Importe=-1;
                if(DealorNo.DevolverCantidadVecesOfertadas()>8){
                    return View("DecisionFinal");
                }
                else{
                return View("Juego");
                }
            }
            else{
                ViewBag.Otro=DealorNo.DecisionOferta(decision);
                ViewBag.Ganador=String.Format("{0:0}",DealorNo.OfertaBanca());
                return View("Final");
            }
        }
        
        public IActionResult DecisionFinal(int maletin)
        {
            ViewBag.Ganador=DealorNo.DecisionFinal(maletin);
            ViewBag.Otro=-1;
            return View("Final");
        }

    }
}

