using System;
using System.Collections.Generic;

namespace TPMALETINES.Models
{
    public static class DealorNo{

        public static List<int> ImportesDescartados = new List<int>();
         private static int[] _ValoresMaletin= new int[]{1,5,10,15,25,50,75,100,200,300,400,500,750,1000,5000,10000,25000,50000,75000,100000,200000,300000,400000,500000,750000,1000000};
         private static Maletin[] _Maletines = new Maletin[26];
         
            private static int[] ValoresMaletin= new int[]{1,5,10,15,25,50,75,100,200,300,400,500,750,1000,5000,10000,25000,50000,75000,100000,200000,300000,400000,500000,750000,1000000};
            private static Maletin _MaletinElegido; 

            private static double Acumulador=0; 

            private static int Contador=0;

            private static double Promedio;

            private static double Oferta;
            private static int _JugadasRestantes = 6;

            private static int _ComienzoJugadas=6;

            private static int _CantOfertas=0;

        public static void IniciarJuego(int Maletin){
            ValoresMaletin= new int[]{1,5,10,15,25,50,75,100,200,300,400,500,750,1000,5000,10000,25000,50000,75000,100000,200000,300000,400000,500000,750000,1000000};            
            _JugadasRestantes=6;
            _ComienzoJugadas=6;
            ImportesDescartados = new List<int>();
            _CantOfertas=0;
            Random rnd=new Random();
            for(int i=0; i<26; i++){
                int pos=rnd.Next(0,26);
                while (ValoresMaletin[pos]==-1){
                    pos= rnd.Next(0,26);
                }
                Maletin Male =  new Maletin(i+1,ValoresMaletin[pos]);
                _Maletines[i]=Male;
                ValoresMaletin[pos]=-1;
            }
            _Maletines[Maletin].Estado=true;
            _MaletinElegido=_Maletines[Maletin];
        }
        public static int abrirMaletin(int numero){
           
            if(_Maletines[numero].Estado==false){
               _Maletines[numero].Estado=true;
               _JugadasRestantes=_JugadasRestantes-1;
               ImportesDescartados.Add(_Maletines[numero].Importe);
               return _Maletines[numero].Importe;
            }
            else{
                return -1;
            }
            
        }
      
        public static int JugadasRestantes(){
           return _JugadasRestantes;
        }

        public static double OfertaBanca(){
            if(_JugadasRestantes==0){
                Acumulador=0;
                Contador=0;
               for(int i=0;i<26;i++){
                 if(_Maletines[i].Estado==false){
                     Acumulador=Acumulador+ _Maletines[i].Importe;
                     Contador++;
                 }
               }
               Promedio=Acumulador / Contador;
               Oferta= Promedio * 0.85;
               
            }
            return Oferta;
        }

        public static int DecisionOferta(string aceptar){
           if(aceptar=="rechazar"){
              if(_ComienzoJugadas==1){
               _ComienzoJugadas++;  
              }    
              _ComienzoJugadas=_ComienzoJugadas-1;
              _JugadasRestantes=_ComienzoJugadas;
              _CantOfertas++;
              return -1;
           }
           else{
              return _MaletinElegido.Importe;
           }
        }

        public static int DecisionFinal(int numero){
            if(_MaletinElegido.Numero==numero){
                return _MaletinElegido.Importe;
            }
            else{
                return _Maletines[numero].Importe;
            }
        }
        
        public static Maletin[] DevolverListaMaletines(){
            return _Maletines;
        }
        public static int[] DevolverListaImportes(){
            return _ValoresMaletin;
        }
        
        public static Maletin DevolverMaletinElegido(){
            return _MaletinElegido;
        }

        public static int DevolverCantidadVecesOfertadas(){
            return _CantOfertas;
        }
    }
    
}