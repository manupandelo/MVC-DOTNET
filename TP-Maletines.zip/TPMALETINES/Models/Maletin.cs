using System;
using System.Collections.Generic;

namespace TPMALETINES.Models
{
    public class Maletin{
        private int _Numero;
        private int _Importe;
        private bool _Estado;

        public int Numero{get{return _Numero;}}
        public int Importe{get{return _Importe;}}
        public bool Estado {get{return _Estado;} set {_Estado=value;}}
        
        public Maletin(int numero, int importe){
            _Numero = numero;
            _Importe = importe;
            _Estado = false;
        }

    }
    
}