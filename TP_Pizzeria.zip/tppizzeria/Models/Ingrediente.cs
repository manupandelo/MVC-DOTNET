using System;
using System.Collections.Generic;

namespace tppizzeria.Models
{
    public class Ingrediente{
        private int _IdIngrediente;
        private string _Nombre;
        private string _UrlFoto;

        public int IdIngrediente{get{return _IdIngrediente;}}
        public string Nombre{get{return _Nombre;}}
        public string UrlFoto {get{return _UrlFoto;}}
        
        public Ingrediente( string Nombre, string Url){
            _IdIngrediente = Pizzeria.UltimoIdIngrediente();
            _Nombre = Nombre;
            _UrlFoto = Url;
        }

    }
    
}