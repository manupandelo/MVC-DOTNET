﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using tppizzeria.Models;

namespace tppizzeria.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

      
        public IActionResult Index()
        {
            return View();
        }
        
        public IActionResult Menu()
        {
            ViewBag.ListarPizzas=Pizzeria.ListarPizzas();
            return View();
        }
        
        public Pizza BuscarPizza(int IdPizza){
            List<Pizza> ListaPizzas=Pizzeria.ListarPizzas();
            foreach(Pizza UnaPizza in ListaPizzas){
                if(UnaPizza.IdPizza == IdPizza){
                    return UnaPizza;
                }
            }
            return null;
        }
        public IActionResult AgregarPizza()
        {
            ViewBag.ListarIngredientes=Pizzeria.ListarIngredientes();
            return View();
        }

        [HttpPost]
        public IActionResult GuardarPizza(string Nombre, string url, string tamano, int precio, List<string> Ingredientes){
            Pizza UnaPizza= new Pizza(Nombre, url, tamano, precio);
            UnaPizza.AgregarIngredientes(Ingredientes);
            Pizzeria.AgregarPizza(UnaPizza);
            ViewBag.ListarPizzas=Pizzeria.ListarPizzas();
            return View("Menu");
        }

        public IActionResult EliminarPizza(int IdPizza){
            Pizza PizzaBuscada=BuscarPizza(IdPizza);
                if(PizzaBuscada!=null){
                    Pizzeria.EliminarPizza(PizzaBuscada);
                }
            ViewBag.ListarPizzas=Pizzeria.ListarPizzas();
            return View("Menu");
        }

        public IActionResult VerPizza(int IdPizza){
            Pizza PizzaBuscada=BuscarPizza(IdPizza);
            if(PizzaBuscada!=null){
                ViewBag.Pizza=PizzaBuscada;
                return View("VerPizza");
            }
            else{
                return View("Menu");
            }
        }



        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
