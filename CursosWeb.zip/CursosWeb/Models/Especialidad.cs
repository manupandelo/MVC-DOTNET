using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
namespace CursosWeb.Models{
    public class Especialidad{
       public int _IdEspecialidad;
       public string _Nombre;
       public string _Materia;
       
       public int IdEspecialidad{get{return _IdEspecialidad;}set{_IdEspecialidad=value;}}
       public string Nombre{get{return _Nombre;}set{_Nombre=value;}}
       public string Materia{get{return _Materia;}set{_Materia=value;}}
       
    }
}