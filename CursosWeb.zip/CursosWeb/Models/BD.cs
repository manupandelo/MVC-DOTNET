using System;
using System.Data.SqlClient;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Dapper;

namespace CursosWeb.Models{
    public static class BD{
        private static string _connectionString=@"Server=DESKTOP-4PRSQU0\SQLEXPRESS; DataBase=BDWebCursos;Trusted_Connection=true;";

        public static Curso ConsultaCurso(int IdCurso){
          Curso CursoBuscado = null;
          string sql="select * from Cursos where IdCurso=@id";
            using(SqlConnection db = new SqlConnection(_connectionString)){
                CursoBuscado = db.QueryFirstOrDefault<Curso>(sql, new{id=IdCurso});    
            }
            return CursoBuscado;

        }

        public static Especialidad ConsultaEspecialidad(int idEspecialidad){
            Especialidad EspecialidadBuscada = null;
            string sql="select * from Especialidades where IdEspecialidad=@id";
            using(SqlConnection db = new SqlConnection(_connectionString)){
                EspecialidadBuscada = db.QueryFirstOrDefault<Especialidad>(sql, new{id=idEspecialidad});    
            }
            return EspecialidadBuscada;
        }

        public static List<Curso> ListarCursos(int idEspecialidad){
           List<Curso> ListaCursos= new List<Curso>();
           string sql;
           if(idEspecialidad==-1){
                sql="select * from Cursos";
               using(SqlConnection db=new SqlConnection(_connectionString)){
                   ListaCursos=db.Query<Curso>(sql).ToList();
               }
           }
           else{
               sql="select * from Cursos where IdEspecialidad=@id";
               using(SqlConnection db=new SqlConnection(_connectionString)){
                   ListaCursos=db.Query<Curso>(sql, new{id=idEspecialidad}).ToList();
               }
           }
           return ListaCursos;
        } 

        public static List<Especialidad> ListarEspecilidades(){
            List<Especialidad> lista=new List<Especialidad>();
            string sql="select * from Especialidades";
            using(SqlConnection db=new SqlConnection(_connectionString)){
            lista=db.Query<Especialidad>(sql).ToList();
            }
            return lista;
        }

        public static void AgregarCurso(Curso cursoAgregar){
            string sql="insert into Cursos (Nombre,Descripcion,Imagen,UrlCurso,MeGusta,NoMeGusta,IdEspecialidad) values (@nombre,@descrip,@urlimg,@urlcurso,0,0,@idespecialidad)";
             using(SqlConnection db = new SqlConnection(_connectionString)){
                db.Execute(sql, new{nombre=cursoAgregar.Nombre, descrip=cursoAgregar.Descripcion, urlimg=cursoAgregar.Imagen, urlcurso=cursoAgregar.UrlCurso, idespecialidad=cursoAgregar.IdEspecialidad});    
            }
        }
        
        public static void CalificarCurso(int idCurso, bool Voto){
            if(Voto==true){
                string sql = "UPDATE Cursos SET MeGusta = MeGusta+1 WHERE IdCurso=@id";    
                using (SqlConnection bd = new SqlConnection(_connectionString)){
                    bd.Execute(sql,new {id=idCurso});
                }
            }
            else{
                string sql = "UPDATE Cursos SET NoMeGusta = NoMeGusta+1 WHERE IdCurso=@id";    
                using (SqlConnection bd = new SqlConnection(_connectionString)){
                    bd.Execute(sql,new {id=idCurso});
                }
            }
        }
    }
}